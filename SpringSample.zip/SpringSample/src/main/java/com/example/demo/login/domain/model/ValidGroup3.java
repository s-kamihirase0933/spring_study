package com.example.demo.login.domain.model;

public interface ValidGroup3{
	
}